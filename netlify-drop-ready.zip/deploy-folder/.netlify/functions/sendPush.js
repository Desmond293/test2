exports.handler = async (event, context) => {
  try {
    console.log("Push notification triggered!");
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "Push notification sent successfully!" })
    };
  } catch (error) {
    console.error("Error sending push:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Failed to send push notification" })
    };
  }
};
